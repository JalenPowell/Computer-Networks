public interface RequestBinConst {
    public static final String DEFAULT_ENCODING = "ISO-8859-1";

    public static final int MAX_OPERAND_LEN = 255; // Max Operand length
    public static final int MAX_WIRE_LENGTH  = 1024; // Max length on the" wire"
}
